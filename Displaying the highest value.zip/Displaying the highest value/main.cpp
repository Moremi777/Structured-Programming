#include <iostream>

using namespace std;

int main()
{
    int arrTemp[5];

    for (int day = 1; day <= 5; day++)
    {
        cout << "Enter the maximum temperature for day " << day << ": ";
        cin >> arrTemp[day];
    }

    cout << "\nList of temperatures" << endl;
    cout << "Day 1: "<< arrTemp[1] << endl;
    cout << "Day 2: "<< arrTemp[2] << endl;
    cout << "Day 3: "<< arrTemp[3] << endl;
    cout << "Day 4: "<< arrTemp[4] << endl;
    cout << "Day 5: "<< arrTemp[5] << endl;

    return 0;
}
