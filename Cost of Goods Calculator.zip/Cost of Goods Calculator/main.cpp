#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float weight = 0.0;
    float cost1 = 3.50;
    float cost2 = 2.85;
    float cost3 = 2.45;

    float amount;

    cout << "Weight (kg):               ";
    cin >> weight;

    if (weight < 2.5)
    {
        cout << "Cost per kg:               R" << cost1 << endl;
        amount = weight * cost1;
        cout << "Amount:                    R" << amount << endl;
    }
    else if (weight < 5)
    {
        cout << "Cost per kg:               R" << cost2 << endl;
        amount = weight * cost2;
        cout << "Amount:                    R" << amount << endl;
    }
    else if (weight > 5)
    {
        cout << "Cost per kg:               R" << cost3 << endl;
        amount = weight * cost3;
        cout << "Amount:                    R" << amount << endl;
    }
    else
    {
        cout << "Please enter a positive value!" << endl;
    }

    return 0;
}
