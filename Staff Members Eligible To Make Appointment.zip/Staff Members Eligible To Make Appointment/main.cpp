#include <iostream>

using namespace std;

int main()
{
    int years, warnings, ratings;

    cout << "Years: ";
    cin >> years;

    cout << "Warnings: ";
    cin >> warnings;

    cout << "Rating: ";
    cin >> ratings;

    if (years >= 3 && ratings >= 8 || warnings <= 1)
    {
        cout << "Status: CAN BE APPOINTED" << endl;

    }
    else
    {
        cout << "Status: CANNOT BE APPOINTED" << endl;
    }

    return 0;
}
