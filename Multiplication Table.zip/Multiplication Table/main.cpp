#include <iostream>

using namespace std;

int main()
{
    int number, last_value;

    cout << "Enter the multiplicator: ";
    cin >> number;

    cout << "Enter the last value of the table: ";
    cin >> last_value;

    for (int count = 1; count <= last_value; count++)
    {
        cout << "\n" << count << "x" << number << " = " << count * number << endl;
    }
    return 0;
}
