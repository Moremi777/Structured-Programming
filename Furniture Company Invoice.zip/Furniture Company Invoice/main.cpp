#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    string name;
    char collection_type;
    int tnumber_delivered, tnumber_collected;
    double tvalue_delivered, tvalue_collected;
    double purchase_amount = 0.0;
    double total_purchases;

    cout << "Enter name of client: \n";
    cin >> name;

    for (int n = 1; n < 20; n++)
    {
        if (toupper(name == "xxx"))
        {
           break;
        }

        cout << "Enter value of purchase: R ";
        cin >> purchase_amount;

        total_purchases = purchase_amount++;

        cout << "Enter type of collection (D or C): ";
        cin >> collection_type;

        cout << "\nEnter name of client (XXX - quit input): \n";
        cin >> name;

    }

    cout << "\nTotal value of purchases: R " << fixed << setprecision(2) << total_purchases << endl;
    cout << "Total number of purchases delivered: R " << fixed << setprecision(2) << tnumber_delivered << endl;
    cout << "Total value of purchases delivered: R " << fixed << setprecision(2) << tvalue_delivered << endl;
    cout << "Total number of purchases collected: R " << fixed << setprecision(2) << tnumber_collected << endl;
    cout << "Total value of purchases collected: R " << fixed << setprecision(2) << tvalue_collected << endl;
    return 0;
}
