#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    string name;
    double price, total_spent, avail_amount;
    string another_order;

    cout << "Name of item?: ";
    cin >> name;

    cout << "Price?: R";
    cin >> price;

    cout << "\n" << name << " placed in the basket." << endl;
    cout << "Amount available: R" << 3000 - price << endl;

    while (true)
    {
        cout << "\nDo you want to order another item(Y or N)?: ";
        cin >> another_order;

        if (another_order == "N")
        {
            break;
        }

        cout << "\nName of item?: ";
        cin >> name;

        cout << "Price?: R";
        cin >> price;

        if (price < 3000)
        {
            cout << "\n" << name << " @ R " << fixed << setprecision(2) << price << endl;
            cout << "Not enough funds available to order this item." << endl;
            cout << "Amount available: R" << 3000 - price << endl;
        }
        else
        {
            cout << "\n" << name << " placed in the basket." << endl;
            cout << "Amount available: R" << 3000 - price << endl;
        }

    }

    cout << "\nTotal amount spent: R " << fixed << setprecision(2) << total_spent << endl;
    cout << "Amount still available: R " << fixed << setprecision(2) << avail_amount << endl;
    return 0;
}
