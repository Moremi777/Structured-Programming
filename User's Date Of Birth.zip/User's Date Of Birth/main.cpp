#include <iostream>

using namespace std;

int main()
{
    int day, month, year;
    string tMonth = "";

    cout << "Enter day of birth: ";
    cin >> day;

    cout << "Enter month of birth: ";
    cin >> month;

    cout << "Enter year of birth: ";
    cin >> year;

    switch(month)
    {
    case 1:
        tMonth = "January";
        break;
    case 2:
        tMonth = "February";
        break;
    case 3:
        tMonth = "March";
        break;
    case 4:
        tMonth = "April";
        break;
    case 5:
        tMonth = "May";
        break;
    case 6:
        tMonth = "June";
        break;
    case 7:
        tMonth = "July";
        break;
    case 8:
        tMonth = "August";
        break;
    case 9:
        tMonth = "September";
        break;
    case 10:
        tMonth = "October";
        break;
    case 11:
        tMonth = "November";
        break;
    case 12:
        tMonth = "December";
        break;

    default:
        tMonth =  "You've entered an invalid value!";
    }

    cout << "\n" << day << " " << tMonth << " " << year << endl;

    return 0;
}
