#include <iostream>

using namespace std;

int main()
{
    int end_value, sum;
    cout << "Enter the end value: ";
    cin >> end_value;

    for (int num = 1; num <= end_value; num++)
    {
        cout << num << " ";
        sum = sum + num;
    }

    cout << "\nThe sum is: " << sum << endl;
    return 0;
}
